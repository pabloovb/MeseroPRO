package com.example.meseropro.util;

public class Constants {
    public static final String SUPABASE_URL = "https://cjumtcnukfzxhjqkodqi.supabase.co/";

    // ⚠️ En un entorno real, esta key debería estar en un lugar seguro.
    public static final String SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNqdW10Y251a2Z6eGhqcWtvZHFpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM2MTk4MzQsImV4cCI6MjA1OTE5NTgzNH0.3-V0_KcOZDJ6ogcjtV11rIZcDxUScwVgpJdDzjX7WVo";
}
